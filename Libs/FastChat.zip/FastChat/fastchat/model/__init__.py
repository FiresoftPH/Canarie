from fastchat.model.model_adapter import (
    load_model,
    get_conversation_template,
    add_model_args,
)
