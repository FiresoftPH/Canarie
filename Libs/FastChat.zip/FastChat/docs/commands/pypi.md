### Requirement
```
python3 -m pip install twine
python3 -m pip install --upgrade pip
pip3 install build
```

### Upload
```
bash scripts/upload_pypi.sh
```
